package com.gmail.dao;


import com.gmail.beans.GmailLogin;

public class GmailLoginDAO {
	public boolean insertLogin(GmailLogin login){
		// we got to connection to db 
		// have a table called login with the attributes 
		// insert it, and return the value as we did in 
		// JDBC 
		return true;
	}
}
